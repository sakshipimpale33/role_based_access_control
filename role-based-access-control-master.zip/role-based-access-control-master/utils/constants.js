module.exports = {
  roles: {
    admin: 'ADMIN',
    moderator: 'MODERATOR',
    client: 'CLIENT',
  },
};
